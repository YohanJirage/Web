var exp = require('express');
var bp = require('body-parser');
var app = exp();

app.use(bp.urlencoded({extended: false }))

 
app.get('/getForm',function(req,resp){
    resp.sendFile(__dirname+"/getForm.html")
})

app.post('/getDataTable',function(req,resp){
     
    var name = req.body.name;
    var bdate = req.body.bdate;
    var email = req.body.email;
    var qual = req.body.qual;
    console.log(name);
   
    str="<table border=1 style ='border-collapse: collapse;'>"
    str+="<tr><td> Name </td><td>"+name+"</td></tr>"+"<tr><td> Birth Date </td><td>"+bdate+"</td></tr>"+"<tr><td> Email </td><td>"+email+"</td></tr>"+"<tr><td> Qualification </td><td>"+qual+"</td></tr>";
    console.log(str)
    resp.send(str)
})

 


app.listen(9000,function(){
    console.log("SERVER IS STARTED")
})